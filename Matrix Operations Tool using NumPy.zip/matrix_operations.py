# matrix_operations.py
"
Matrix Operations Tool (CLI)
Features:
- Input matrices manually or load from CSV files
- Addition, Subtraction, Multiplication
- Transpose, Determinant (for square matrices)
- Nicely formatted output
"
import numpy as np
import sys
import csv
from pathlib import Path

def read_matrix_from_csv(path):
    try:
        arr = np.loadtxt(path, delimiter=',')
        # If single row becomes 1D, convert to 2D
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        return arr
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return None

def input_matrix(prompt="Enter matrix (rows comma-separated; semicolon between rows)\nExample: 1,2;3,4\n> "):
    raw = input(prompt).strip()
    try:
        rows = [r.strip() for r in raw.split(';') if r.strip()]
        mat = [list(map(float, row.split(','))) for row in rows]
        return np.array(mat)
    except Exception as e:
        print(f"Invalid input: {e}")
        return None

def print_matrix(m):
    with np.printoptions(precision=3, suppress=True):
        print(m)

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a.dot(b)

def transpose(a):
    return a.T

def determinant(a):
    return float(np.linalg.det(a))

def choose_matrix(name):
    print(f"\nProvide matrix for {name}:")
    print("1) Enter manually")
    print("2) Load from CSV file (path)")
    choice = input("Choose (1/2): ").strip()
    if choice == '1':
        return input_matrix()
    elif choice == '2':
        path = input("Enter CSV file path: ").strip()
        return read_matrix_from_csv(path)
    else:
        print("Invalid choice")
        return None

def main():
    menu = '''\
\nMatrix Operations Tool
1) Addition (A + B)
2) Subtraction (A - B)
3) Multiplication (A x B)
4) Transpose (Aᵀ)
5) Determinant (det(A))
6) Exit
'''
    while True:
        print(menu)
        choice = input('Select operation (1-6): ').strip()
        if choice == '1':
            A = choose_matrix('A')
            B = choose_matrix('B')
            if A is None or B is None: continue
            if A.shape != B.shape:
                print('Error: Matrices must have the same shape for addition.')
                continue
            print('\nResult (A + B):')
            print_matrix(add(A, B))
        elif choice == '2':
            A = choose_matrix('A')
            B = choose_matrix('B')
            if A is None or B is None: continue
            if A.shape != B.shape:
                print('Error: Matrices must have the same shape for subtraction.')
                continue
            print('\nResult (A - B):')
            print_matrix(subtract(A, B))
        elif choice == '3':
            A = choose_matrix('A')
            B = choose_matrix('B')
            if A is None or B is None: continue
            if A.shape[1] != B.shape[0]:
                print('Error: Number of columns in A must equal number of rows in B for multiplication.')
                continue
            print('\nResult (A x B):')
            print_matrix(multiply(A, B))
        elif choice == '4':
            A = choose_matrix('A')
            if A is None: continue
            print('\nResult (Aᵀ):')
            print_matrix(transpose(A))
        elif choice == '5':
            A = choose_matrix('A')
            if A is None: continue
            if A.shape[0] != A.shape[1]:
                print('Error: Determinant is defined only for square matrices.')
                continue
            print('\nDeterminant (det(A)):')
            try:
                det = determinant(A)
                print(f"{det:.6f}")
            except Exception as e:
                print(f"Error computing determinant: {e}")
        elif choice == '6':
            print('Exiting.')
            sys.exit(0)
        else:
            print('Invalid choice. Please select from 1-6.')

if __name__ == '__main__':
    main()
