# 🧮 Matrix Operations Tool (NumPy)

## 📌 Internship Task – Slab 1 (Task 3)

This project provides a simple **Matrix Operations Tool** built with **Python** and **NumPy**.
It allows users to input matrices or load them from CSV files and perform common matrix operations.

---

## 🔹 Features
- Matrix Addition (A + B)
- Matrix Subtraction (A - B)
- Matrix Multiplication (A x B)
- Transpose (Aᵀ)
- Determinant (det(A)) for square matrices
- Interactive command-line interface (menu-driven)

---

## 🔹 How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the tool:
   ```bash
   python matrix_operations.py
   ```
3. Follow prompts to enter matrices manually (e.g., `1,2;3,4`) or load from CSV file.

---

## 🔹 Input Format (Manual)
- Enter rows separated by semicolons, values separated by commas.
- Example for a 2x2 matrix: `1,2;3,4`

---

## 🔹 Loading from CSV
- Provide a path to a CSV file where each row is a matrix row, values separated by commas.
- Example CSV content for 2x2 matrix:
  ```csv
  1,2
  3,4
  ```

---

## 🔹 Project Files
- `matrix_operations.py` → Main interactive tool
- `README.md` → Documentation
- `requirements.txt` → Dependencies
- `sample_matrices/` → Example CSV matrices (included)
- `Insights_Observations.md` → Notes and example outputs

---

## 📌 Author
- Internship Task – Python Development
- Submitted by: **[Your Name]**
